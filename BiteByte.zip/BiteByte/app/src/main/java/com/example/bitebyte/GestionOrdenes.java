package com.example.bitebyte;

import com.google.firebase.database.*;
import com.example.bitebyte.Orden;

import java.util.TreeMap;

public class GestionOrdenes {

    private TreeMap<String, Orden> ordenes = new TreeMap<>();
    private DatabaseReference refOrdenes = FirebaseDatabase.getInstance().getReference("ordenes");

    public void agregarOrden(Orden orden) {
        ordenes.put(orden.getIdOrden(), orden);
        refOrdenes.child(orden.getIdOrden()).setValue(orden);
    }

    public void borrarOrden(String idOrden) {
        ordenes.remove(idOrden);
        refOrdenes.child(idOrden).removeValue();
    }

    public Orden obtenerOrden(String idOrden) {
        return ordenes.get(idOrden);
    }

    public void actualizarEstado(String idOrden, EstadoOrden nuevoEstado) {
        Orden orden = ordenes.get(idOrden);
        if (orden != null) {
            orden.setEstado(nuevoEstado);
            refOrdenes.child(idOrden).setValue(orden);
        }
    }
    public void cargarOrdenesDesdeFirebase() {
        refOrdenes.get().addOnSuccessListener(snapshot -> {
            ordenes.clear();
            for (DataSnapshot ds : snapshot.getChildren()) {
                Orden orden = ds.getValue(Orden.class);
                ordenes.put(orden.getIdOrden(), orden);
            }
        });
    }
}
