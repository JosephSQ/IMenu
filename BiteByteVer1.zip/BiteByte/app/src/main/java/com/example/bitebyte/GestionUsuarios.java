package com.example.bitebyte;

import java.util.HashMap;
import com.google.firebase.database.*;
import com.example.bitebyte.Usuario;

public class GestionUsuarios {

    private final HashMap<String, Usuario> usuarios = new HashMap<>();
    private final DatabaseReference refUsuarios = FirebaseDatabase.getInstance().getReference("usuarios");

    public void agregarUsuario(Usuario usuario) {
        usuarios.put(usuario.getId(), usuario);
        refUsuarios.child(usuario.getId()).setValue(usuario);
    }

    public void borrarUsuario(String id) {
        usuarios.remove(id);
        refUsuarios.child(id).removeValue();
    }

    public Usuario obtenerUsuario(String id) {
        return usuarios.get(id);
    }

    public void cargarUsuariosDesdeFirebase() {
        refUsuarios.get().addOnSuccessListener(snapshot -> {
            usuarios.clear();
            for (DataSnapshot ds : snapshot.getChildren()) {
                Usuario usuario = ds.getValue(Usuario.class);
                usuarios.put(usuario.getId(), usuario);
            }
        });
    }
}
