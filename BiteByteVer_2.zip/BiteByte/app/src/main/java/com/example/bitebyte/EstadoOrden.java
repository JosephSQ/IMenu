package com.example.bitebyte;

public enum EstadoOrden {
    PENDIENTE,
    EN_PROCESO,
    COMPLETADA,
    EN_PREPARACION,
    CANCELADA
}